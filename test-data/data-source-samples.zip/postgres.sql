CREATE TABLE demo_inventory (sku TEXT PRIMARY KEY, stock INTEGER NOT NULL);
INSERT INTO demo_inventory VALUES ('PG-206', 73);
