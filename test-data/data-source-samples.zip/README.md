# 数据源自测样例

## 上传文件

在「文档 → 上传文档」选一个可写的知识库。逐个上传 `upload/` 下的样例，等待「就绪」后查看文档详情中的文本片段。

| 样例 | 预期结果 |
|---|---|
| manual.pdf | 第 1 页出现 ORCHID-101 和 24 months，第 2 页出现 ORCHID-102 和 37 units |
| office.docx、office.doc | 出现「旧版 Office 验收记录」 |
| office.xlsx、office.xls | 表格行出现「旧版 Office 验收记录」 |
| slides.pptx、slides.ppt | 第 1 页包含 RRF，第 2 页包含 BM25 |
| notice.txt | ORCHID-105 保修 18 个月 |
| guide.md | ORCHID-106 每 90 天校准一次 |
| page.html | ORCHID-107 每 30 天保养一次，索引中应找不到 IGNORE_HTML_SCRIPT |
| ocr.png | 上传后点击「开始视觉解析」，核对 ORCHID-108 和 685 CNY |

DOC 和 XLS 需要后端安装 LibreOffice。PPT 和 PPTX 是用于抽取文本和检查页序的最小测试件，Office 原文预览可能不可用。OCR 需要已配置的视觉模型。

## 导入外部源

1. 在系统中准备一个可写测试知识库，记下它的 ID。知识库页面的「查看文档」会跳转到带有 `kb=<ID>` 的地址。
2. 解压后在样例目录打开 PowerShell。假设知识库 ID 为 1，执行 `python .\serve.py --kb-id 1`，将 1 换成你的 ID。保留该窗口。
3. 把脚本打印的 `RAG_DATA_SOURCES_FILE="…/sources.json"` 写入项目的 `backend/.env`。如果已有同名设置，先记下原值再替换。重启后端。
4. 打开「文档 → 上传文档」，选择对应知识库，在「资料来源」逐一选择样例，然后点击「导入并处理」。

| 来源 | 预期结果 |
|---|---|
| 网页 | WEB-201，培训 45 分钟 |
| API | API-202，库存 37 |
| 对象存储 | OBJ-203，保留 120 天 |
| 企业网盘 | DRIVE-204，审批 5 天 |
| SQLite | SQL-205，库存 52 |

网页、API、对象存储、企业网盘均由本机 HTTP 样例服务提供。API 样例会校验配置中的演示令牌。真实对象存储测试可把 `object` 的 URL 换成有效的预签名下载地址。企业网盘测试可把 `drive` 的 URL 换成最终下载地址，按需增加认证请求头。配置中的文件扩展名应与实际响应一致。

如有独立的 PostgreSQL 测试库，可以运行包内 `postgres.sql` 写入演示记录，然后在生成的 `sources.json` 数组中添加一项。将知识库 ID 和 DSN 改成实际值，导入账号只需对演示表有 SELECT 权限。

```json
{"id":"pg","label":"PostgreSQL 样例","kind":"database","knowledge_base_id":1,"filename":"postgres.csv","dsn":"postgresql://reader:PASSWORD@127.0.0.1:5432/testdb","query":"SELECT sku, stock FROM demo_inventory"}
```

PostgreSQL 样例预期出现 PG-206 和库存 73。测试完成后可停止样例服务并恢复 `backend/.env`。
