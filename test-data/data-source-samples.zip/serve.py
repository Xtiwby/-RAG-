from argparse import ArgumentParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
ROUTES = {
    'web': ('web', '网页样例', 'web.html', 'text/html; charset=utf-8'),
    'api': ('api', 'API 样例', 'api.json', 'application/json'),
    'object': ('object', '对象存储样例', 'object.txt', 'text/plain; charset=utf-8'),
    'drive': ('drive', '企业网盘样例', 'drive.txt', 'text/plain; charset=utf-8'),
}
TOKEN = 'Bearer demo-source-token'


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        route = self.path.removeprefix('/')
        if route not in ROUTES:
            self.send_error(404)
            return
        if route == 'api' and self.headers.get('Authorization') != TOKEN:
            self.send_error(401)
            return
        _, _, filename, media_type = ROUTES[route]
        body = (ROOT / 'http' / filename).read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', media_type)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main():
    parser = ArgumentParser()
    parser.add_argument('--kb-id', type=int, required=True)
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    base = f'http://127.0.0.1:{args.port}'
    sources = []
    for route, (kind, label, filename, _) in ROUTES.items():
        source = dict(id=route, label=label, kind=kind, filename=filename,
                      knowledge_base_id=args.kb_id, url=f'{base}/{route}')
        if route == 'api':
            source['headers'] = {'Authorization': TOKEN}
        sources.append(source)
    sources.append(dict(id='sqlite', label='SQLite 样例', kind='database',
                        filename='sqlite.csv', knowledge_base_id=args.kb_id,
                        sqlite_path=str(ROOT / 'inventory.sqlite'),
                        query='SELECT sku, stock FROM inventory ORDER BY sku'))
    config = ROOT / 'sources.json'
    with ThreadingHTTPServer(('127.0.0.1', args.port), Handler) as server:
        config.write_text(json.dumps(sources, indent=2, ensure_ascii=False), encoding='utf-8')
        print(f'RAG_DATA_SOURCES_FILE="{config.as_posix()}"', flush=True)
        print(f'Listening on {base}', flush=True)
        server.serve_forever()


if __name__ == '__main__':
    main()
